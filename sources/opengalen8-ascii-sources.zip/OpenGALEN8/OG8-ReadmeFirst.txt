###################################################################
##                                                               ##
## OpenGALEN Common Reference Model Release 8 - OWL Translations ##
##                                                               ##
###################################################################

Unlike the preceding releases of OpenGALEN Common Reference Models versions 2 through 7, the OWL translation of OpenGALEN CRM release 8 is provided not as a single OWL ontology file but as a (recursively nested) series of 83 OWL ontology components. The entire ontology can be imported by opening the stub ontology OpenGALEN8_FULL.owl, which imports the major components which, in turn, recursively import further subcomponents. It is therefore also possible to import only various fragments of the model.

[The Nov-2009 release of OpenGALEN 8 OWL also provided the ontology as a single monolithic 500Mb OWL file; this has been discontinued. The componentised version appears to be sufficient, whilst the monolithic file could not be loaded into at least some OWL tooling, including PROT�G�]

It is hoped that this partial componentisation may provide DL reasoner researchers with a means to construct suitable customised reasoning challenges over and above the obvious 'compile everything' approach. It may also highlight some of the requirements and challenges for DL tool builders with respect to managing large ontologies as components; an OWL tooling solution capable of recreating and managing the original Model Source Unit hierarchy would be a particularly interesting prospect.

The componentised release of OpenGALEN Release 8 comprises four major components:

1. The OpenGALEN Common Reference Model (CRM) version 8 - OpenGALEN8_CRM.owl
2. The Diseases Extension - OpenGALEN8_DissectionsDisease.owl
3. The Surgical Procedures Extension - OpenGALEN8_DissectionsSurgicalProcedure.owl
4. The Drug Ontology Extension - OpenGALEN8_DissectionsDrugOntology.owl

## OpenGALEN Common Reference Model (CRM) version 8 ##

CRM v8 is very similar in content and scope to OpenGALEN Release 7, and is the direct descendent of all preceding releases from OpenGALEN Release 2. 

The stub ontology OpenGALEN8_CRM.owl uses the <owl:imports> construct to import the various components of the CRM itself as further stub ontologies (the generic top ontology, the medical foundation model and the medical domain extensions) each of which, in turn, import their major subcomponents.

Note that this componentisation of the CRM allows for simple removal of the property chain axiom element of OpenGALEN 8: in OpenGALEN8_GenericModel.owl, simply delete the following line:

<owl:imports><owl:Ontology rdf:about="OpenGALEN8_GenericModel_PropertyChainAxioms.owl"/></owl:imports>

## OpenGALEN Model version 8 - Dissection Extensions ##

The three Dissection Extensions are previously unreleased content, comprising a significant corpus that sits on top of the CRM and for which the CRM was originally created. They may be loaded and reasoned over either individually (but as extensions to the CRM) or all together. The Diseases and Surgical Procedures extensions comprise exclusively of further defined entities and associated annotations; there are no further existential restrictions. The drug ontology is larger and more complex: it also includes many additional existential restrictions.

The 'stub' ontology OpenGALEN8_FULL.owl imports all three Dissection Extensions as further discrete stub ontologies. Each of these then additionally imports the Dissections Model (a required small additional ontology which also imports the Common Reference Model via the OpenGALEN8_CRM.owl stub ontology), and its own subcomponent ontologies. 

Manchester UK
October 16th 2009